"""처리 담당: 문서 목록과 키워드로 일치 횟수를 계산하고 전략으로 정렬한다."""
def search(docs, keyword, strategy):
    hits = []
    for d in docs:
        c = d.text.lower().count(keyword.lower())
        if c > 0:
            hits.append((d.name, c))
    return strategy.sort(hits)
