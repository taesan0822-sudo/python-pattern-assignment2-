"""저장 담당: 검색 이력을 CSV에 추가한다."""
class HistoryStore:
    def __init__(self, path="history.csv"):
        self.path = path
    def append(self, keyword, hit_files):
        with open(self.path, "a", encoding="utf-8") as f:
            f.write("%s,%d\n" % (keyword, hit_files))
