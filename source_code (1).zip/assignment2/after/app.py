"""연결 담당(CLI): 입력 검사 -> 읽기 -> 검색(+정렬 전략) -> 출력 -> 저장 순서만 조율한다."""
import sys
from loader import load_documents, FolderNotFound
from search_service import search
from strategies import get_strategy
from history import HistoryStore

def format_results(results):
    if not results:
        return "검색 결과 없음"
    return "\n".join("[%d] %s - %d회" % (i, n, c) for i, (n, c) in enumerate(results, 1))

def main(argv):
    if len(argv) < 2:
        print("사용법: app.py <폴더> <키워드> [--history 파일] [--sort name|count]")
        return 2
    folder, keyword = argv[0], argv[1].strip()
    hist = argv[argv.index("--history") + 1] if "--history" in argv else "history.csv"
    sort_key = argv[argv.index("--sort") + 1] if "--sort" in argv else "name"
    if not keyword:
        print("오류: 키워드가 비어 있습니다."); return 1
    try:
        strategy = get_strategy(sort_key)
    except ValueError as e:
        print("오류: " + str(e)); return 1
    try:
        docs = load_documents(folder)
    except FolderNotFound:
        print("오류: 폴더가 없습니다: " + folder); return 1
    if not docs:
        print("TXT 파일이 없습니다."); return 0
    results = search(docs, keyword, strategy)
    print(format_results(results))
    HistoryStore(hist).append(keyword, len(results))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
