"""입력 담당: 폴더에서 TXT 문서를 읽는다. (검색 규칙·정렬·저장은 모른다)"""
import os
from dataclasses import dataclass

@dataclass
class Document:
    name: str
    text: str

class FolderNotFound(Exception): pass

def load_documents(folder):
    if not os.path.isdir(folder):
        raise FolderNotFound(folder)
    docs = []
    for n in os.listdir(folder):
        if n.lower().endswith(".txt"):
            with open(os.path.join(folder, n), encoding="utf-8") as f:
                docs.append(Document(n, f.read()))
    return docs
