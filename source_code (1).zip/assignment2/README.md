# 개인 자료 검색 도구 (Strategy 패턴 리팩터링 + 웹 화면)

GitHub 저장소: https://github.com/taesan0822-sudo/python-pattern-assignment2-

## 환경
- Python 3.9 이상. 외부 패키지 없음(requirements.txt 불필요, 표준 라이브러리만 사용).
- 검사한 버전: Python 3.15.2 (Windows, 학생 실행), Python 3.12 (AI 작성 시 확인)

## 폴더 구성
| 폴더/파일 | 내용 |
|---|---|
| `before/search_before.py` | 구조 개선 전: 한 파일에 모든 기능 |
| `after_refactor/` | 구조 개선 후(Strategy 적용, 정렬은 이름순만). 진입점 `app.py` |
| `after/` | 작은 변경 후(일치도순 `--sort count` 추가). 진입점 `app.py` |
| `web/server.py` | 웹 화면(선택 가산점). `after/` 모듈 재사용 |
| `tests/run_checks.py` | CLI 검사(개선 전/후/변경 후 비교, T1~T6, C1~C2) |
| `tests/run_web_checks.py` | 웹 검사(W1~W9) |
| `data/docs/`, `data/empty/` | 예시 TXT 3개, 빈 폴더 |
| `logs/` | 실행 로그, 부호 실험 로그, 개선 후→변경 후 diff, 웹 캡처(`web_screenshot.png`) |

## 실행 방법 (모든 명령은 이 README가 있는 폴더에서 실행)
1. 폴더 열기: Windows는 탐색기에서 이 폴더를 열고 주소창에 `cmd` 입력 후 Enter
2. 버전 확인: `python --version`  (맥은 `python3`)
3. 개선 전: `python before/search_before.py data/docs python`
4. 구조 개선 후: `python after_refactor/app.py data/docs python`
5. 기능 변경 후(일치도순): `python after/app.py data/docs python --sort count`
   - 이력은 기본 `history.csv`에 추가되며 `--history 경로`로 바꿀 수 있다.
6. 웹: `python web/server.py` 실행 후 브라우저에서 http://127.0.0.1:8000 접속 (종료 Ctrl+C)

## 검사 방법
- `python tests/run_checks.py`  -> 20개 검사 PASS/FAIL, 마지막 줄 `동작 보존 ... True | 실패 수: 0`, 결과는 `tests/results.json`
- `python tests/run_web_checks.py` -> W1~W9 PASS/FAIL
- 로그 저장: `python tests/run_checks.py > logs/check_cli.txt`
- 검사 ID는 보고서와 같다: T1~T6(유지되어야 하는 검사), C1~C2(변경 후 새 검사), W1~W9(웹)

출처: 직접 구성. Strategy 패턴은 GoF 『Design Patterns』(1994)와 수업에서 다룬 디자인 패턴 내용 참고. 웹은 표준 라이브러리 http.server 사용.
