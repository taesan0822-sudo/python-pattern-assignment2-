"""구조 개선 전: 한 파일에 입력 검사 / 읽기 / 검색 / 정렬 / 출력 / 저장이 섞여 있는 기본 프로그램."""
import os, sys

def main(argv):
    if len(argv) < 2:
        print("사용법: search_before.py <폴더> <키워드> [--history 파일]")
        return 2
    folder, keyword = argv[0], argv[1].strip()
    hist = "history.csv"
    if "--history" in argv:
        hist = argv[argv.index("--history") + 1]
    if not keyword:
        print("오류: 키워드가 비어 있습니다.")
        return 1
    if not os.path.isdir(folder):
        print("오류: 폴더가 없습니다: " + folder)
        return 1
    names = [n for n in os.listdir(folder) if n.lower().endswith(".txt")]
    if not names:
        print("TXT 파일이 없습니다.")
        return 0
    results = []
    for n in names:
        with open(os.path.join(folder, n), encoding="utf-8") as f:
            c = f.read().lower().count(keyword.lower())
        if c > 0:
            results.append((n, c))
    results.sort(key=lambda r: r[0])          # 파일명순 (고정)
    if not results:
        print("검색 결과 없음")
    else:
        for i, (n, c) in enumerate(results, 1):
            print("[%d] %s - %d회" % (i, n, c))
    with open(hist, "a", encoding="utf-8") as f:
        f.write("%s,%d\n" % (keyword, len(results)))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
