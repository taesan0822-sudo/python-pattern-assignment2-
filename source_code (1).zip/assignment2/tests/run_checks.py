"""검사 코드: 같은 입력을 세 단계(before / after_refactor / after)에 넣고 출력·종료코드·저장값을 비교한다."""
import subprocess, sys, os, tempfile, json
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STAGES = {"before": "before/search_before.py", "refactor": "after_refactor/app.py", "change": "after/app.py"}
D, E = "data/docs", "data/empty"
CASES = [  # (id, 분류, 인자, 기대 출력, 기대 종료코드, 기대 이력)
 ("T1","정상",[D,"python"],"[1] bio_notes.txt - 2회\n[2] physics_lab.txt - 4회",0,"python,2\n"),
 ("T2","경계(결과 없음)",[D,"zebra"],"검색 결과 없음",0,"zebra,0\n"),
 ("T3","경계(빈 폴더)",[E,"python"],"TXT 파일이 없습니다.",0,""),
 ("T4","잘못된 입력(빈 키워드)",[D,"  "],"오류: 키워드가 비어 있습니다.",1,""),
 ("T5","잘못된 입력(없는 폴더)",["data/nothing","python"],"오류: 폴더가 없습니다: data/nothing",1,""),
 ("T6","경계(대소문자)",[D,"PYTHON"],"[1] bio_notes.txt - 2회\n[2] physics_lab.txt - 4회",0,"PYTHON,2\n"),
]
CHANGE_ONLY = [
 ("C1","기능 변경(일치도순)",[D,"python","--sort","count"],"[1] physics_lab.txt - 4회\n[2] bio_notes.txt - 2회",0,"python,2\n"),
 ("C2","잘못된 입력(없는 정렬)",[D,"python","--sort","date"],"오류: 알 수 없는 정렬 방식: date",1,""),
]
def run(stage, args):
    with tempfile.TemporaryDirectory() as t:
        h = os.path.join(t, "h.csv")
        r = subprocess.run([sys.executable, STAGES[stage], *args, "--history", h], cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
        hist = open(h, encoding="utf-8").read() if os.path.exists(h) else ""
    return r.stdout.strip(), r.returncode, hist
if __name__ == "__main__":
    rows, bad = [], 0
    for stage in STAGES:
        for cid, kind, args, eo, ec, eh in CASES + (CHANGE_ONLY if stage == "change" else []):
            o, c, h = run(stage, args)
            ok = (o, c, h) == (eo, ec, eh)
            bad += not ok
            rows.append({"stage": stage, "id": cid, "kind": kind, "ok": ok, "out": o, "code": c, "hist": h})
            print(("PASS" if ok else "FAIL"), stage, cid, kind)
    same = all(next(r for r in rows if r["stage"]==a and r["id"]==i)[k] == next(r for r in rows if r["stage"]==b and r["id"]==i)[k]
               for i in [c[0] for c in CASES] for k in ("out","code","hist") for a,b in (("before","refactor"),("refactor","change")))
    print("동작 보존(T1~T6 세 단계 동일):", same, "| 실패 수:", bad)
    json.dump(rows, open(os.path.join(ROOT,"tests","results.json"),"w",encoding="utf-8"), ensure_ascii=False, indent=1)
    sys.exit(1 if bad or not same else 0)
