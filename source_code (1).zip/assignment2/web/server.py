"""웹 화면(선택 가산점): 표준 라이브러리 http.server만 사용. after/ 의 모듈(loader, search_service,
strategies, history)을 그대로 재사용하므로 검색·정렬·저장 규칙은 CLI와 같다. 이 파일은 '입력 폼 -> 기존 모듈 호출 -> HTML 출력'만 맡는다.
실행: python web/server.py  ->  http://127.0.0.1:8000"""
import os, sys, html
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "after"))
from loader import load_documents, FolderNotFound
from search_service import search
from strategies import get_strategy, STRATEGIES
from history import HistoryStore

DATA = os.path.join(ROOT, "data")
HIST_PATH = os.environ.get("WEB_HISTORY", os.path.join(ROOT, "web_history.csv"))
LABELS = {"name": "파일명순", "count": "일치도순(횟수 많은 순)"}

def list_folders():
    return sorted(d for d in os.listdir(DATA) if os.path.isdir(os.path.join(DATA, d)))

def do_search(folder, keyword, sort_key, hist_path):
    """CLI의 main()과 같은 순서: 입력 검사 -> 읽기 -> 검색 -> (저장). 반환: (상태, 메시지, 결과리스트)"""
    keyword = keyword.strip()
    if not keyword:
        return "error", "오류: 키워드가 비어 있습니다.", []
    try:
        strategy = get_strategy(sort_key)
    except ValueError as e:
        return "error", "오류: " + str(e), []
    if folder not in list_folders():           # 폴더 이름은 data/ 아래 목록만 허용(경로 조작 방지)
        return "error", "오류: 폴더가 없습니다: " + folder, []
    try:
        docs = load_documents(os.path.join(DATA, folder))
    except FolderNotFound:
        return "error", "오류: 폴더가 없습니다: " + folder, []
    if not docs:
        return "info", "TXT 파일이 없습니다.", []
    results = search(docs, keyword, strategy)
    HistoryStore(hist_path).append(keyword, len(results))
    return "ok", ("검색 결과 없음" if not results else ""), results

def read_history(path, n=10):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [l.rstrip("\n") for l in f][-n:][::-1]

def render(params, hist_path=HIST_PATH):
    e = html.escape
    folder = params.get("folder", ["docs"])[0]
    keyword = params.get("q", [None])[0]
    sort_key = params.get("sort", ["name"])[0]
    body = ""
    if keyword is not None:
        status, msg, results = do_search(folder, keyword, sort_key, hist_path)
        if msg:
            body += '<p class="%s">%s</p>' % (status, e(msg))
        if results:
            body += "<table><tr><th>#</th><th>파일</th><th>일치 횟수</th></tr>"
            for i, (n, c) in enumerate(results, 1):
                body += "<tr><td>%d</td><td>%s</td><td>%d회</td></tr>" % (i, e(n), c)
            body += "</table>"
    fopts = "".join('<option value="%s"%s>%s</option>' % (e(f), " selected" if f == folder else "", e(f)) for f in list_folders())
    sopts = "".join('<option value="%s"%s>%s</option>' % (k, " selected" if k == sort_key else "", LABELS.get(k, k)) for k in STRATEGIES)
    hist = "".join("<li>%s</li>" % e(l) for l in read_history(hist_path)) or "<li>(아직 없음)</li>"
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>개인 자료 검색</title>
<style>body{{font-family:sans-serif;max-width:640px;margin:2em auto}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #999;padding:4px 8px}}.error{{color:#b00020}}.info{{color:#555}}</style></head><body>
<h1>개인 자료 검색</h1>
<form method="get"><label>폴더 <select name="folder">{fopts}</select></label>
<label>키워드 <input name="q" value="{e(keyword or '')}"></label>
<label>정렬 <select name="sort">{sopts}</select></label> <button>검색</button></form>
{body}<h3>최근 검색 이력 (키워드,결과 파일 수)</h3><ul>{hist}</ul></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        u = urlparse(self.path)
        if u.path != "/":
            self.send_error(404); return
        data = render(parse_qs(u.query)).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers(); self.wfile.write(data)
    def log_message(self, *a): pass

def make_server(port=8000):
    return ThreadingHTTPServer(("127.0.0.1", port), Handler)

if __name__ == "__main__":
    print("http://127.0.0.1:8000 에서 실행 중 (종료: Ctrl+C)")
    make_server().serve_forever()
