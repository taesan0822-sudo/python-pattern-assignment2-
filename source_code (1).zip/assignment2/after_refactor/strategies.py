"""처리 담당(Strategy 패턴): 검색 결과를 정렬하는 방법을 교체 가능한 객체로 분리한다."""
from abc import ABC, abstractmethod

class SortStrategy(ABC):
    @abstractmethod
    def sort(self, results):
        """results: [(파일명, 일치횟수)] -> 정렬된 새 리스트"""

class NameSort(SortStrategy):
    def sort(self, results):
        return sorted(results, key=lambda r: r[0])

STRATEGIES = {"name": NameSort}

def get_strategy(key):
    if key not in STRATEGIES:
        raise ValueError("알 수 없는 정렬 방식: " + key)
    return STRATEGIES[key]()
