# 개인 자료 검색 도구 (Strategy 패턴 리팩터링 + 웹 화면)

GitHub 저장소: https://github.com/taesan0822-sudo/python-pattern-assignment2-

- Python 3.9 이상 (외부 패키지 없음, requirements.txt 불필요). 개발·검사: Python 3.12
- 구성: `before/` 개선 전 단일 파일, `after_refactor/` 구조 개선 후(정렬=이름순만), `after/` 작은 변경 후(일치도순 추가), `web/` 웹 화면(선택 가산점)
- 예시 데이터: `data/docs/`(TXT 3개), `data/empty/`(빈 폴더)

## 터미널 실행
- 개선 후: `python after/app.py data/docs python --sort count`  (이력은 기본 `history.csv`, `--history 경로`로 변경)
- 개선 전: `python before/search_before.py data/docs python`

## 웹 실행 (선택 가산점)
1. 프로젝트 최상위 폴더에서 `python web/server.py`
2. 브라우저에서 http://127.0.0.1:8000 접속 (종료: Ctrl+C)
3. 폴더(data/ 아래 목록)·키워드·정렬(파일명순/일치도순)을 고르고 [검색]. 결과 표와 최근 검색 이력(`web_history.csv`)이 화면에 나온다.
- 웹은 `after/`의 loader, search_service, strategies, history 모듈을 그대로 재사용한다.

## 검사
- `python tests/run_checks.py` : CLI 세 단계(개선 전/후/변경 후)의 PASS/FAIL과 동작 보존 여부, 결과는 `tests/results.json`
- `python tests/run_web_checks.py` : 웹 서버를 임시 포트로 띄워 W1~W9 확인

출처: 직접 작성. Strategy 패턴은 GoF 『Design Patterns』(1994)의 개념을 수업 자료 기준으로 적용. 웹은 Python 표준 라이브러리 http.server 사용.
