# 개인 자료 검색 도구 (Strategy 패턴 리팩터링)

- Python 3.9 이상 (외부 패키지 없음, requirements.txt 불필요). 개발·검사: Python 3.12
- 구성: `before/` 개선 전 단일 파일, `after_refactor/` 구조 개선 후(정렬=이름순만), `after/` 작은 변경 후(일치도순 추가)
- 예시 데이터: `data/docs/`(TXT 3개), `data/empty/`(빈 폴더)
- 실행: `python after/app.py data/docs python --sort count`  (이력은 기본 `history.csv`에 추가, `--history 경로`로 변경)
- 개선 전: `python before/search_before.py data/docs python`
- 검사: `python tests/run_checks.py` -> 세 단계의 PASS/FAIL과 동작 보존 여부 출력, `tests/results.json`에 실제 결과 기록
- 출처: 직접 작성. Strategy 패턴은 GoF 『Design Patterns』(1994)의 개념을 수업 자료 기준으로 적용.
