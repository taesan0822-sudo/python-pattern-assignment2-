"""연결 담당(CLI): 입력 검사 -> 읽기 -> 검색(+정렬 전략) -> 출력 -> 저장 순서만 조율한다.
종료코드: 0 정상(결과 없음·빈 폴더 포함), 1 입력 오류, 2 인자 부족(사용법 출력)."""
import sys
from loader import load_documents, FolderNotFound
from search_service import search
from strategies import get_strategy
from history import HistoryStore

def format_results(results):
    if not results:
        return "검색 결과 없음"
    return "\n".join("[%d] %s - %d회" % (i, n, c) for i, (n, c) in enumerate(results, 1))

def get_option(argv, name, default):
    """옵션 값이 없거나 바로 다음이 다른 옵션(--로 시작)이면 ValueError로 오류 처리한다."""
    if name not in argv:
        return default
    i = argv.index(name)
    if i + 1 >= len(argv) or argv[i + 1].startswith("--"):
        raise ValueError(name + " 옵션에 값이 필요합니다.")
    return argv[i + 1]

def main(argv):
    if len(argv) < 2:
        print("사용법: app.py <폴더> <키워드> [--history 파일]")
        return 2
    folder, keyword = argv[0], argv[1].strip()
    try:
        hist = get_option(argv, "--history", "history.csv")
    except ValueError as e:
        print("오류: " + str(e)); return 1
    sort_key = "name"            # 구조 개선 단계: 정렬 방식은 이름순으로 고정
    if not keyword:
        print("오류: 키워드가 비어 있습니다."); return 1
    try:
        strategy = get_strategy(sort_key)
    except ValueError as e:
        print("오류: " + str(e)); return 1
    try:
        docs = load_documents(folder)
    except FolderNotFound:
        print("오류: 폴더가 없습니다: " + folder); return 1
    if not docs:
        print("TXT 파일이 없습니다."); return 0
    results = search(docs, keyword, strategy)
    print(format_results(results))
    HistoryStore(hist).append(keyword, len(results))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
