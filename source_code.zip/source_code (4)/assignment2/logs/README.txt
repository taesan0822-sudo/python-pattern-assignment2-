로그 목록 (실행 주체 / Python / 코드 버전 / 내용)
- v1_student_py3.15.2_windows/ : 학생 / 3.15.2 / v1 / CLI 20개 PASS, CountSort 부호 실험(C1 FAIL -> 복구)
- v2_student_py3.15.2_windows/ : 학생 / 3.15.2 / v2 / CLI 28개 + 웹 9개 PASS
- v3_ai_py3.12_linux/          : AI(Perplexity) 실행 환경 / 3.12 / v3 / CLI 38개 + 웹 10개 PASS
- v3_student_py3.15.2_windows/ : 학생 / 3.15.2 / v3 (현재) / CLI 38개 + 웹 10개 PASS
- diff_refactor_to_change.txt  : 구조 개선 후(after_refactor) -> 기능 변경 후(after) diff
- web_screenshot.png           : 웹 화면 캡처(학생 저장)
각 check_*.txt 첫 줄에 실행 환경과 코드 버전이 적혀 있다.
