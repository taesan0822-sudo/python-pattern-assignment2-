# 개인 자료 검색 도구 (Strategy 패턴 리팩터링 + 웹 화면)

GitHub 저장소: https://github.com/taesan0822-sudo/python-pattern-assignment2-

## 환경
- Python 3.9 이상. 외부 패키지 없음(requirements.txt 불필요, 표준 라이브러리만 사용).
- 현재 코드 버전: v3. 실행 확인: Python 3.15.2 (Windows, 학생), Python 3.12 (Linux, AI 환경)

## 폴더 구성
| 폴더/파일 | 내용 |
|---|---|
| `before/search_before.py` | 구조 개선 전: 한 파일에 모든 기능 |
| `after_refactor/` | 구조 개선 후(Strategy 적용, 정렬은 이름순 고정). 진입점 `app.py` |
| `after/` | 작은 변경 후(일치도순 `--sort count` 추가). 진입점 `app.py` |
| `web/server.py` | 웹 화면(선택 가산점). `after/` 모듈 재사용 |
| `tests/run_checks.py` | CLI 검사: 세 단계 비교 T1~T10, 인자 부족 U1, 변경 후 C1~C5 |
| `tests/run_web_checks.py` | 웹 검사 W1~W10 |
| `data/docs/`, `data/tie/`, `data/empty/` | 예시 TXT, 횟수 동점 예시, 빈 폴더 |
| `logs/` | 검사 로그(폴더별 실행 주체·Python·코드 버전은 `logs/README.txt`), diff, 웹 캡처 |

## 실행 방법 (모든 명령은 이 README가 있는 폴더에서 실행)
1. Windows: 탐색기에서 이 폴더를 열고 주소창에 `cmd` 입력 후 Enter
2. `python --version` (맥은 `python3`)
3. 개선 전: `python before/search_before.py data/docs python`
4. 구조 개선 후: `python after_refactor/app.py data/docs python`
5. 기능 변경 후: `python after/app.py data/docs python --sort count`
   - 이력은 `history.csv`에 csv 형식으로 추가되며 `--history 경로`로 바꿀 수 있다.
6. 웹: `python web/server.py` 후 브라우저에서 http://127.0.0.1:8000 (종료 Ctrl+C)

## 종료코드(CLI)
| 코드 | 의미 |
|---|---|
| 0 | 정상 종료(결과 없음, TXT 없는 폴더 포함) |
| 1 | 입력 오류(빈 키워드, 없는 폴더, 없는 정렬, 옵션 값 누락 등) |
| 2 | 인자 부족(사용법 출력) |
웹은 종료코드가 없고, 입력 오류를 화면에 메시지로 표시한다.

## 검사 방법
- `python tests/run_checks.py` -> 38개 검사(세 단계 공통 T1~T10과 U1, 변경 후 C1~C5), 마지막 줄 `동작 보존 ... True | 실패 수: 0`, 결과는 `tests/results.json`
- `python tests/run_web_checks.py` -> W1~W10
- 로그 저장: `python tests/run_checks.py > logs/v3_student_py3.15.2_windows/check_cli.txt` (폴더를 먼저 만들 것)

출처: Strategy 패턴은 GoF 『Design Patterns』(1994)와 과제2 안내문(기말 과제)이 참고하라고 한 수업의 함수·객체·입출력·저장·디자인 패턴 내용. 웹은 표준 라이브러리 http.server, 이력 저장은 표준 라이브러리 csv 사용.
