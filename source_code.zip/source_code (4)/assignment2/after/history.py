"""저장 담당: 검색 이력을 CSV에 추가한다. csv 모듈을 써서 쉼표·따옴표가 있는 키워드도 두 필드 구조를 유지한다."""
import csv

class HistoryStore:
    def __init__(self, path="history.csv"):
        self.path = path
    def append(self, keyword, hit_files):
        with open(self.path, "a", encoding="utf-8", newline="") as f:
            csv.writer(f, lineterminator="\n").writerow([keyword, hit_files])
