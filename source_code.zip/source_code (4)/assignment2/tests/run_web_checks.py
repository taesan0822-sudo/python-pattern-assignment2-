"""웹 검사: 서버를 임시 포트로 띄우고 HTTP 요청으로 CLI와 같은 결과가 화면에 나오는지 확인한다. 첫 줄에 실행 환경을 출력한다."""
import os, sys, tempfile, threading, urllib.request, urllib.parse, platform
CODE_VERSION = "v3"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
tmp = tempfile.mkdtemp()
os.environ["WEB_HISTORY"] = os.path.join(tmp, "h.csv")
sys.path.insert(0, os.path.join(ROOT, "web"))
import server
srv = server.make_server(0)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
def get(**kw):
    return urllib.request.urlopen("http://127.0.0.1:%d/?%s" % (port, urllib.parse.urlencode(kw))).read().decode("utf-8")
def pos(h, a, b): return a in h and b in h and h.index(a) < h.index(b)
CHECKS = [
 ("W1","정상(이름순)", lambda: get(folder="docs", q="python", sort="name"), lambda h: pos(h,"bio_notes.txt","physics_lab.txt") and "2회" in h and "4회" in h),
 ("W2","기능 변경(일치도순)", lambda: get(folder="docs", q="python", sort="count"), lambda h: pos(h,"physics_lab.txt","bio_notes.txt")),
 ("W3","경계(결과 없음)", lambda: get(folder="docs", q="zebra", sort="name"), lambda h: "검색 결과 없음" in h),
 ("W4","경계(빈 폴더)", lambda: get(folder="empty", q="python", sort="name"), lambda h: "TXT 파일이 없습니다." in h),
 ("W5","오류(빈 키워드)", lambda: get(folder="docs", q="  ", sort="name"), lambda h: "키워드가 비어 있습니다" in h),
 ("W6","오류(없는 폴더)", lambda: get(folder="../after", q="python", sort="name"), lambda h: "폴더가 없습니다" in h and "loader.py" not in h),
 ("W7","오류(없는 정렬)", lambda: get(folder="docs", q="python", sort="date"), lambda h: "알 수 없는 정렬 방식" in h),
 ("W8","이력 저장 확인", lambda: get(), lambda h: "python,2" in h and "zebra,0" in h and "PYTHON" not in h),
 ("W9","XSS 방지(태그 이스케이프)", lambda: get(folder="docs", q="<b>x</b>", sort="name"), lambda h: "<b>x</b>" not in h and "&lt;b&gt;x&lt;/b&gt;" in h),
 ("W10","경계(쉼표 키워드가 이력에 한 항목으로 표시)", lambda: get(folder="docs", q="a,b", sort="name"), lambda h: "&quot;a,b&quot;,0" in h),
]
print("# 실행 환경: Python %s (%s), 코드 버전 %s" % (platform.python_version(), platform.system(), CODE_VERSION))
bad = 0
for cid, name, fn, ok in CHECKS:
    r = ok(fn()); bad += not r
    print("PASS" if r else "FAIL", cid, name)
hist = open(os.environ["WEB_HISTORY"], encoding="utf-8").read()
print("웹 이력 파일:", repr(hist))
print("실패 수:", bad)
srv.shutdown(); sys.exit(1 if bad else 0)
