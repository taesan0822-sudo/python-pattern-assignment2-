"""검사 코드: 같은 입력을 세 단계(before / after_refactor / after)에 넣고 출력·종료코드·'생성된 이력 파일'을 비교한다.
각 검사는 빈 임시 폴더를 작업 폴더로 삼아 실행하므로, 오류 입력에서 기본 이력 경로(history.csv)나
명시한 이력 경로(h.csv)에 파일이 생기지 않았는지까지 확인할 수 있다. 로그 첫 줄에 실행 환경을 출력한다.
mode: 'h' = 끝에 --history h.csv 를 붙임 / 'raw' = 인자를 그대로 넘김(기본 이력 경로는 임시 폴더의 history.csv)"""
import subprocess, sys, os, tempfile, json, platform
CODE_VERSION = "v4"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STAGES = {"before": "before/search_before.py", "refactor": "after_refactor/app.py", "change": "after/app.py"}
D, E, TIE = (os.path.join(ROOT, "data", x) for x in ("docs", "empty", "tie"))
TIE_NAME = "[1] a_note.txt - 2회\n[2] m_note.txt - 3회\n[3] z_note.txt - 2회"
BOTH = "[1] bio_notes.txt - 2회\n[2] physics_lab.txt - 4회"
H = "h.csv"
# (id, 분류, 인자, mode, 기대 출력, 기대 종료코드, 기대로 생성되어야 하는 파일 {이름: 내용})
CASES = [
 ("T1","정상",[D,"python"],"h",BOTH,0,{H:"python,2\n"}),
 ("T2","경계(결과 없음)",[D,"zebra"],"h","검색 결과 없음",0,{H:"zebra,0\n"}),
 ("T3","경계(빈 폴더)",[E,"python"],"h","TXT 파일이 없습니다.",0,{}),
 ("T4","잘못된 입력(빈 키워드)",[D,"  "],"h","오류: 키워드가 비어 있습니다.",1,{}),
 ("T5","잘못된 입력(없는 폴더)",["data/nothing","python"],"h","오류: 폴더가 없습니다: data/nothing",1,{}),
 ("T6","경계(대소문자)",[D,"PYTHON"],"h",BOTH,0,{H:"PYTHON,2\n"}),
 ("T7","잘못된 입력(--history 값 없음)",[D,"python","--history"],"raw","오류: --history 옵션에 값이 필요합니다.",1,{}),
 ("T8","경계(횟수가 같은 파일, 이름순)",[TIE,"apple"],"h",TIE_NAME,0,{H:"apple,3\n"}),
 ("T9","경계(쉼표가 있는 키워드)",[D,"a,b"],"h","검색 결과 없음",0,{H:'"a,b",0\n'}),
 ("T10","잘못된 입력(옵션 바로 뒤에 다른 옵션)",[D,"python","--history","--x"],"raw","오류: --history 옵션에 값이 필요합니다.",1,{}),
 ("T11","경계(키워드가 --sort)",[D,"--sort"],"h","검색 결과 없음",0,{H:"--sort,0\n"}),
 ("T12","정상(기본 이력 경로 history.csv)",[D,"python"],"raw",BOTH,0,{"history.csv":"python,2\n"}),
]
CHANGE_ONLY = [
 ("C1","기능 변경(일치도순)",[D,"python","--sort","count"],"h","[1] physics_lab.txt - 4회\n[2] bio_notes.txt - 2회",0,{H:"python,2\n"}),
 ("C2","잘못된 입력(없는 정렬)",[D,"python","--sort","date"],"h","오류: 알 수 없는 정렬 방식: date",1,{}),
 ("C3","잘못된 입력(--sort 값 없음)",[D,"python","--sort"],"raw","오류: --sort 옵션에 값이 필요합니다.",1,{}),
 ("C4","경계(횟수 동점, 일치도순)",[TIE,"apple","--sort","count"],"h","[1] m_note.txt - 3회\n[2] a_note.txt - 2회\n[3] z_note.txt - 2회",0,{H:"apple,3\n"}),
 ("C5","잘못된 입력(--sort 바로 뒤에 다른 옵션)",[D,"python","--sort","--history","h.csv"],"raw","오류: --sort 옵션에 값이 필요합니다.",1,{}),
 ("C6","경계(키워드가 --sort이고 --sort count도 지정)",[D,"--sort","--sort","count"],"h","검색 결과 없음",0,{H:"--sort,0\n"}),
]
USAGE = {  # 인자 부족: 종료코드 2, 단계별 사용법 문구(단계 간 비교 대상 아님)
 "before": "사용법: search_before.py <폴더> <키워드> [--history 파일]",
 "refactor": "사용법: app.py <폴더> <키워드> [--history 파일]",
 "change": "사용법: app.py <폴더> <키워드> [--history 파일] [--sort name|count]",
}
def run(stage, args, mode):
    with tempfile.TemporaryDirectory() as t:        # 빈 임시 폴더를 작업 폴더로 사용
        cmd = [sys.executable, os.path.join(ROOT, STAGES[stage]), *args] + (["--history", H] if mode == "h" else [])
        r = subprocess.run(cmd, cwd=t, capture_output=True, text=True, encoding="utf-8")
        files = {n: open(os.path.join(t, n), encoding="utf-8").read() for n in sorted(os.listdir(t))}
    return r.stdout.strip(), r.returncode, files
if __name__ == "__main__":
    print("# 실행 환경: Python %s (%s), 코드 버전 %s" % (platform.python_version(), platform.system(), CODE_VERSION))
    rows, bad = [], 0
    for stage in STAGES:
        for cid, kind, args, mode, eo, ec, ef in CASES + (CHANGE_ONLY if stage == "change" else []):
            o, c, f = run(stage, args, mode)
            ok = (o, c, f) == (eo, ec, ef)
            bad += not ok
            rows.append({"stage": stage, "id": cid, "kind": kind, "ok": ok, "out": o, "code": c, "files": f})
            print(("PASS" if ok else "FAIL"), stage, cid, kind)
            if not ok:
                print("   예상:", repr(eo), ec, repr(ef)); print("   실제:", repr(o), c, repr(f))
        o, c, f = run(stage, [], "raw")
        ok = (o, c, f) == (USAGE[stage], 2, {})
        bad += not ok
        rows.append({"stage": stage, "id": "U1", "kind": "인자 부족(사용법, 종료코드 2)", "ok": ok, "out": o, "code": c, "files": f})
        print(("PASS" if ok else "FAIL"), stage, "U1 인자 부족(사용법, 종료코드 2)")
    ids = [c[0] for c in CASES]
    for i in ids:
        for k in ("out", "code", "files"):
            vals = {s: next(r for r in rows if r["stage"] == s and r["id"] == i)[k] for s in STAGES}
            if len(set(map(str, vals.values()))) != 1:
                print("   단계별 불일치:", i, k, vals)
    same = all(next(r for r in rows if r["stage"]==a and r["id"]==i)[k] == next(r for r in rows if r["stage"]==b and r["id"]==i)[k]
               for i in ids for k in ("out","code","files") for a,b in (("before","refactor"),("refactor","change")))
    print("동작 보존(T1~T12 세 단계 동일):", same, "| 실패 수:", bad)
    json.dump(rows, open(os.path.join(ROOT,"tests","results.json"),"w",encoding="utf-8"), ensure_ascii=False, indent=1)
    sys.exit(1 if bad or not same else 0)
